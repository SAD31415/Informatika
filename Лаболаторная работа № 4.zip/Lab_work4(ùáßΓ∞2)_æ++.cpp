﻿#include <iostream>
#include <vector>
#include <algorithm>

std::vector<int> findIntersection(const std::vector<int>& setA, const std::vector<int>& setB) {
    std::vector<int> intersection;

    for (int element : setA) {
        if (std::find(setB.begin(), setB.end(), element) != setB.end()) {
            if (std::find(intersection.begin(), intersection.end(), element) == intersection.end()) {
                intersection.push_back(element);
            }
        }
    }

    return intersection;
}

int calculateSum(const std::vector<int>& arr) {
    int sum = 0;
    for (int element : arr) {
        sum += element;
    }
    return sum;
}

std::vector<int> inputSet(const std::string& setName) {
    std::vector<int> set;
    int n, element;

    std::cout << "Введите количество элементов множества " << setName << ": ";
    std::cin >> n;

    std::cout << "Введите элементы множества " << setName << ":" << std::endl;
    for (int i = 0; i < n; i++) {
        std::cout << "Элемент " << i + 1 << ": ";
        std::cin >> element;

        if (std::find(set.begin(), set.end(), element) == set.end()) {
            set.push_back(element);
        }
        else {
            std::cout << "Элемент " << element << " уже есть в множестве, пропускаем." << std::endl;
            i--; 
        }
    }

    return set;
}

int main() {
    setlocale(LC_ALL, "rus");
    std::vector<int> setA = inputSet("A");
    std::vector<int> setB = inputSet("B");

    std::vector<int> intersection = findIntersection(setA, setB);

    int sum = calculateSum(intersection);

    std::cout << "\nМножество A: [";
    for (size_t i = 0; i < setA.size(); i++) {
        std::cout << setA[i] << (i < setA.size() - 1 ? ", " : "");
    }
    std::cout << "]" << std::endl;

    std::cout << "Множество B: [";
    for (size_t i = 0; i < setB.size(); i++) {
        std::cout << setB[i] << (i < setB.size() - 1 ? ", " : "");
    }
    std::cout << "]" << std::endl;

    std::cout << "Пересечение A∩B: [";
    for (size_t i = 0; i < intersection.size(); i++) {
        std::cout << intersection[i] << (i < intersection.size() - 1 ? ", " : "");
    }
    std::cout << "]" << std::endl;

    std::cout << "Сумма элементов пересечения: " << sum << std::endl;

    return 0;
}