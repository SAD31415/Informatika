﻿#include <iostream>
#include <vector>

std::vector<int> filterPositiveElements(const int arr[], int size) {
    std::vector<int> result;

    for (int i = 0; i < size; i++) {
        if (arr[i] > 0) {
            result.push_back(arr[i]);
        }
    }

    return result;
}

void printArray(const std::vector<int>& arr, const std::string& name) {
    std::cout << name << " = [";
    for (size_t i = 0; i < arr.size(); i++) {
        std::cout << arr[i];
        if (i < arr.size() - 1) {
            std::cout << ", ";
        }
    }
    std::cout << "]" << std::endl;
}

int main() {
    setlocale(LC_ALL, "rus");
    const int SIZE = 10;
    int arrayA[SIZE];

    std::cout << "Введите 10 элементов массива A:" << std::endl;
    for (int i = 0; i < SIZE; i++) {
        std::cout << "A[" << i << "] = ";
        std::cin >> arrayA[i];
    }

    std::vector<int> arrayB = filterPositiveElements(arrayA, SIZE);

    printArray(std::vector<int>(arrayA, arrayA + SIZE), "Массив A");
    printArray(arrayB, "Массив B (положительные элементы)");
    std::cout << "Количество положительных элементов: " << arrayB.size() << std::endl;

    return 0;
}