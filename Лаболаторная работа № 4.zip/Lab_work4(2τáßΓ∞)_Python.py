A = set()
n = int(input("Сколько элементов в множестве A? "))
for i in range(n):
    num = int(input(f"Введите элемент {i+1}: "))
    A.add(num)

B = set()
m = int(input("Сколько элементов в множестве B? "))
for i in range(m):
    num = int(input(f"Введите элемент {i+1}: "))
    B.add(num)

intersection = A.intersection(B)
sum_result = sum(intersection)
print("Пересечение:", intersection)
print("Сумма:", sum_result)