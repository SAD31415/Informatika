A = []
for i in range(10):
    num = int(input(f"Введите элемент A[{i}]: "))
    A.append(num)

B = []
for x in A:
    if x > 0:
        B.append(x)

print("Массив B:", B)